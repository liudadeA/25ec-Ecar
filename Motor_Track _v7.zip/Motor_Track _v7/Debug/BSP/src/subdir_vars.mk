################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../BSP/src/Four_gpio.c \
../BSP/src/bsp_tb6612.c \
../BSP/src/oled_hardware_i2c.c \
../BSP/src/uart_driver.c 

C_DEPS += \
./BSP/src/Four_gpio.d \
./BSP/src/bsp_tb6612.d \
./BSP/src/oled_hardware_i2c.d \
./BSP/src/uart_driver.d 

OBJS += \
./BSP/src/Four_gpio.o \
./BSP/src/bsp_tb6612.o \
./BSP/src/oled_hardware_i2c.o \
./BSP/src/uart_driver.o 

OBJS__QUOTED += \
"BSP\src\Four_gpio.o" \
"BSP\src\bsp_tb6612.o" \
"BSP\src\oled_hardware_i2c.o" \
"BSP\src\uart_driver.o" 

C_DEPS__QUOTED += \
"BSP\src\Four_gpio.d" \
"BSP\src\bsp_tb6612.d" \
"BSP\src\oled_hardware_i2c.d" \
"BSP\src\uart_driver.d" 

C_SRCS__QUOTED += \
"../BSP/src/Four_gpio.c" \
"../BSP/src/bsp_tb6612.c" \
"../BSP/src/oled_hardware_i2c.c" \
"../BSP/src/uart_driver.c" 


