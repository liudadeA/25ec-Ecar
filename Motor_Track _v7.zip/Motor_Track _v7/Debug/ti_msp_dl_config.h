/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define GPIO_HFXT_PORT                                                     GPIOA
#define GPIO_HFXIN_PIN                                             DL_GPIO_PIN_5
#define GPIO_HFXIN_IOMUX                                         (IOMUX_PINCM10)
#define GPIO_HFXOUT_PIN                                            DL_GPIO_PIN_6
#define GPIO_HFXOUT_IOMUX                                        (IOMUX_PINCM11)
#define CPUCLK_FREQ                                                     80000000



/* Defines for PWM_0 */
#define PWM_0_INST                                                         TIMA1
#define PWM_0_INST_IRQHandler                                   TIMA1_IRQHandler
#define PWM_0_INST_INT_IRQN                                     (TIMA1_INT_IRQn)
#define PWM_0_INST_CLK_FREQ                                             10000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_0_C0_PORT                                                 GPIOA
#define GPIO_PWM_0_C0_PIN                                         DL_GPIO_PIN_17
#define GPIO_PWM_0_C0_IOMUX                                      (IOMUX_PINCM39)
#define GPIO_PWM_0_C0_IOMUX_FUNC                     IOMUX_PINCM39_PF_TIMA1_CCP0
#define GPIO_PWM_0_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_0_C1_PORT                                                 GPIOA
#define GPIO_PWM_0_C1_PIN                                         DL_GPIO_PIN_16
#define GPIO_PWM_0_C1_IOMUX                                      (IOMUX_PINCM38)
#define GPIO_PWM_0_C1_IOMUX_FUNC                     IOMUX_PINCM38_PF_TIMA1_CCP1
#define GPIO_PWM_0_C1_IDX                                    DL_TIMER_CC_1_INDEX



/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMA0)
#define TIMER_0_INST_IRQHandler                                 TIMA0_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMA0_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                           (999U)




/* Defines for I2C_OLED */
#define I2C_OLED_INST                                                       I2C0
#define I2C_OLED_INST_IRQHandler                                 I2C0_IRQHandler
#define I2C_OLED_INST_INT_IRQN                                     I2C0_INT_IRQn
#define I2C_OLED_BUS_SPEED_HZ                                             400000
#define GPIO_I2C_OLED_SDA_PORT                                             GPIOA
#define GPIO_I2C_OLED_SDA_PIN                                      DL_GPIO_PIN_0
#define GPIO_I2C_OLED_IOMUX_SDA                                   (IOMUX_PINCM1)
#define GPIO_I2C_OLED_IOMUX_SDA_FUNC                    IOMUX_PINCM1_PF_I2C0_SDA
#define GPIO_I2C_OLED_SCL_PORT                                             GPIOA
#define GPIO_I2C_OLED_SCL_PIN                                      DL_GPIO_PIN_1
#define GPIO_I2C_OLED_IOMUX_SCL                                   (IOMUX_PINCM2)
#define GPIO_I2C_OLED_IOMUX_SCL_FUNC                    IOMUX_PINCM2_PF_I2C0_SCL


/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_FREQUENCY                                           40000000
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOA
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                        DL_GPIO_PIN_11
#define GPIO_UART_0_TX_PIN                                        DL_GPIO_PIN_10
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM22)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM21)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM21_PF_UART0_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_0_FBRD_40_MHZ_115200_BAUD                                      (45)





/* Port definition for Pin Group LED */
#define LED_PORT                                                         (GPIOB)

/* Defines for PIN: GPIOB.22 with pinCMx 50 on package pin 21 */
#define LED_PIN_PIN                                             (DL_GPIO_PIN_22)
#define LED_PIN_IOMUX                                            (IOMUX_PINCM50)
/* Port definition for Pin Group TB6612 */
#define TB6612_PORT                                                      (GPIOA)

/* Defines for AIN1: GPIOA.14 with pinCMx 36 on package pin 7 */
#define TB6612_AIN1_PIN                                         (DL_GPIO_PIN_14)
#define TB6612_AIN1_IOMUX                                        (IOMUX_PINCM36)
/* Defines for AIN2: GPIOA.15 with pinCMx 37 on package pin 8 */
#define TB6612_AIN2_PIN                                         (DL_GPIO_PIN_15)
#define TB6612_AIN2_IOMUX                                        (IOMUX_PINCM37)
/* Defines for BIN1: GPIOA.12 with pinCMx 34 on package pin 5 */
#define TB6612_BIN1_PIN                                         (DL_GPIO_PIN_12)
#define TB6612_BIN1_IOMUX                                        (IOMUX_PINCM34)
/* Defines for BIN2: GPIOA.13 with pinCMx 35 on package pin 6 */
#define TB6612_BIN2_PIN                                         (DL_GPIO_PIN_13)
#define TB6612_BIN2_IOMUX                                        (IOMUX_PINCM35)
/* Port definition for Pin Group ENCODER */
#define ENCODER_PORT                                                     (GPIOB)

/* Defines for E1A: GPIOB.13 with pinCMx 30 on package pin 1 */
// groups represented: ["Task_Set","ENCODER"]
// pins affected: ["Start_Set","COUNT","TASK_SET","Count_Zero","E1A","E2A"]
#define GPIO_MULTIPLE_GPIOB_INT_IRQN                            (GPIOB_INT_IRQn)
#define GPIO_MULTIPLE_GPIOB_INT_IIDX            (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define ENCODER_E1A_IIDX                                    (DL_GPIO_IIDX_DIO13)
#define ENCODER_E1A_PIN                                         (DL_GPIO_PIN_13)
#define ENCODER_E1A_IOMUX                                        (IOMUX_PINCM30)
/* Defines for E1B: GPIOB.14 with pinCMx 31 on package pin 2 */
#define ENCODER_E1B_PIN                                         (DL_GPIO_PIN_14)
#define ENCODER_E1B_IOMUX                                        (IOMUX_PINCM31)
/* Defines for E2A: GPIOB.15 with pinCMx 32 on package pin 3 */
#define ENCODER_E2A_IIDX                                    (DL_GPIO_IIDX_DIO15)
#define ENCODER_E2A_PIN                                         (DL_GPIO_PIN_15)
#define ENCODER_E2A_IOMUX                                        (IOMUX_PINCM32)
/* Defines for E2B: GPIOB.16 with pinCMx 33 on package pin 4 */
#define ENCODER_E2B_PIN                                         (DL_GPIO_PIN_16)
#define ENCODER_E2B_IOMUX                                        (IOMUX_PINCM33)
/* Defines for DH_1: GPIOA.26 with pinCMx 59 on package pin 30 */
#define GPIO_GRP_Sensor_DH_1_PORT                                        (GPIOA)
#define GPIO_GRP_Sensor_DH_1_PIN                                (DL_GPIO_PIN_26)
#define GPIO_GRP_Sensor_DH_1_IOMUX                               (IOMUX_PINCM59)
/* Defines for DH_2: GPIOA.27 with pinCMx 60 on package pin 31 */
#define GPIO_GRP_Sensor_DH_2_PORT                                        (GPIOA)
#define GPIO_GRP_Sensor_DH_2_PIN                                (DL_GPIO_PIN_27)
#define GPIO_GRP_Sensor_DH_2_IOMUX                               (IOMUX_PINCM60)
/* Defines for DH_3: GPIOA.24 with pinCMx 54 on package pin 25 */
#define GPIO_GRP_Sensor_DH_3_PORT                                        (GPIOA)
#define GPIO_GRP_Sensor_DH_3_PIN                                (DL_GPIO_PIN_24)
#define GPIO_GRP_Sensor_DH_3_IOMUX                               (IOMUX_PINCM54)
/* Defines for DH_4: GPIOA.25 with pinCMx 55 on package pin 26 */
#define GPIO_GRP_Sensor_DH_4_PORT                                        (GPIOA)
#define GPIO_GRP_Sensor_DH_4_PIN                                (DL_GPIO_PIN_25)
#define GPIO_GRP_Sensor_DH_4_IOMUX                               (IOMUX_PINCM55)
/* Defines for DH_5: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GPIO_GRP_Sensor_DH_5_PORT                                        (GPIOB)
#define GPIO_GRP_Sensor_DH_5_PIN                                (DL_GPIO_PIN_24)
#define GPIO_GRP_Sensor_DH_5_IOMUX                               (IOMUX_PINCM52)
/* Defines for DH_6: GPIOB.25 with pinCMx 56 on package pin 27 */
#define GPIO_GRP_Sensor_DH_6_PORT                                        (GPIOB)
#define GPIO_GRP_Sensor_DH_6_PIN                                (DL_GPIO_PIN_25)
#define GPIO_GRP_Sensor_DH_6_IOMUX                               (IOMUX_PINCM56)
/* Defines for DH_7: GPIOA.22 with pinCMx 47 on package pin 18 */
#define GPIO_GRP_Sensor_DH_7_PORT                                        (GPIOA)
#define GPIO_GRP_Sensor_DH_7_PIN                                (DL_GPIO_PIN_22)
#define GPIO_GRP_Sensor_DH_7_IOMUX                               (IOMUX_PINCM47)
/* Defines for DH_8: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GPIO_GRP_Sensor_DH_8_PORT                                        (GPIOB)
#define GPIO_GRP_Sensor_DH_8_PIN                                (DL_GPIO_PIN_20)
#define GPIO_GRP_Sensor_DH_8_IOMUX                               (IOMUX_PINCM48)
/* Defines for DH_TURN_1: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GPIO_GRP_Sensor_DH_TURN_1_PORT                                   (GPIOB)
#define GPIO_GRP_Sensor_DH_TURN_1_PIN                           (DL_GPIO_PIN_18)
#define GPIO_GRP_Sensor_DH_TURN_1_IOMUX                          (IOMUX_PINCM44)
/* Defines for DH_TURN_2: GPIOB.17 with pinCMx 43 on package pin 14 */
#define GPIO_GRP_Sensor_DH_TURN_2_PORT                                   (GPIOB)
#define GPIO_GRP_Sensor_DH_TURN_2_PIN                           (DL_GPIO_PIN_17)
#define GPIO_GRP_Sensor_DH_TURN_2_IOMUX                          (IOMUX_PINCM43)
/* Port definition for Pin Group Task_Set */
#define Task_Set_PORT                                                    (GPIOB)

/* Defines for Start_Set: GPIOB.7 with pinCMx 24 on package pin 59 */
#define Task_Set_Start_Set_IIDX                              (DL_GPIO_IIDX_DIO7)
#define Task_Set_Start_Set_PIN                                   (DL_GPIO_PIN_7)
#define Task_Set_Start_Set_IOMUX                                 (IOMUX_PINCM24)
/* Defines for COUNT: GPIOB.6 with pinCMx 23 on package pin 58 */
#define Task_Set_COUNT_IIDX                                  (DL_GPIO_IIDX_DIO6)
#define Task_Set_COUNT_PIN                                       (DL_GPIO_PIN_6)
#define Task_Set_COUNT_IOMUX                                     (IOMUX_PINCM23)
/* Defines for TASK_SET: GPIOB.9 with pinCMx 26 on package pin 61 */
#define Task_Set_TASK_SET_IIDX                               (DL_GPIO_IIDX_DIO9)
#define Task_Set_TASK_SET_PIN                                    (DL_GPIO_PIN_9)
#define Task_Set_TASK_SET_IOMUX                                  (IOMUX_PINCM26)
/* Defines for Count_Zero: GPIOB.8 with pinCMx 25 on package pin 60 */
#define Task_Set_Count_Zero_IIDX                             (DL_GPIO_IIDX_DIO8)
#define Task_Set_Count_Zero_PIN                                  (DL_GPIO_PIN_8)
#define Task_Set_Count_Zero_IOMUX                                (IOMUX_PINCM25)
#define GPIOB_EVENT_PUBLISHER_0_CHANNEL                                      (2)



/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_SYSCTL_CLK_init(void);
void SYSCFG_DL_PWM_0_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_I2C_OLED_init(void);
void SYSCFG_DL_UART_0_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
